# CTS-285
# M1T1-Orientation
# Elizabeth Battenfield
# 8/16/2021

"""
Orientation Introduction
"""
print()
print("Hello!\n")
print( "I'm Elizabeth Battenfield.\n\n")
print("This semester I have a full study load!\n\n")
print( "I am studying Advanced C++ and Advanced Python!\n\n")
print( "I am also studying:\n      Operating System Concenpts,\n      System Analysis and Design, and\n      Linux/Single User (aka Red Hat System Administration 1)\n\n")
print( "I am a single mother, I am currently not working as I am a full-time student.\n\n")
print( "I am planning on graduating this coming spring, and hope to get a good job using what I've learned here at FTCC.\n\n")
print( "My hobbies include listening to music, reading, playing video games, and watching youtube/twitch streamers.\n\n")
print( " I am also spending my time making my own personal projects using Python and C++.\n\n")
print( "My current long term project is a text-based Pokemon game.\n")

#yes, i used the exact same as the C++ i had alread done. 