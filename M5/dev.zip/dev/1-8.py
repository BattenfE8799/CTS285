# coding: utf-8
from textblob import TextBlob

text = "Today is a beautiful day. Tommorrow looks like bad weather."

blob = TextBlob(text)

blob.sentences
blob.words
blob.tags
get_ipython().run_line_magic('save', '1-8 textblob_sample 1-8')
